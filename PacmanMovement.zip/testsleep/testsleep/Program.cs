﻿// See https://aka.ms/new-console-template for more information
using System.Threading;

Console.WriteLine("Hello, World!");

String string1 = "C";
for (int y = 0; y < 100; y++)
{
    switch (y)
    {
        case 0:
            Console.WriteLine($"{string1}");
            break;
        case 1:
            Console.WriteLine(" C");
            break;
        case 2:
            Console.WriteLine("  C");
            break;
        case 3:
            Console.WriteLine("   C");
            break;
        case 4:
            Console.WriteLine("    C");
            break;
        case 5:
            Console.WriteLine("     C");
            break;
        case 6:
            Console.WriteLine("      C");
            break;
        case 7:
            Console.WriteLine("       C");
            break;
        case 8:
            Console.WriteLine("        C");
            break;
        case 9:
            Console.WriteLine("         C");
            break;
        case 10:
            Console.WriteLine("          C");
            break;
        case 11:
            Console.WriteLine("           C");
            break;
        case 12:
            Console.WriteLine();
            Console.WriteLine($"{string1}");
            break;
        case 13:
            Console.WriteLine();
            Console.WriteLine(" C");
            break;
        case 14:
            Console.WriteLine();
            Console.WriteLine("  C");
            break;
        case 15:
            Console.WriteLine();
            Console.WriteLine("   C");
            break;
        case 16:
            Console.WriteLine();
            Console.WriteLine("    C");
            break;
        case 17:
            Console.WriteLine();
            Console.WriteLine("     C");
            break;
        case 18:
            Console.WriteLine();
            Console.WriteLine("      C");
            break;
        case 19:
            Console.WriteLine();
            Console.WriteLine("       C");
            break;
        case 20:
            Console.WriteLine();
            Console.WriteLine("        C");
            break;
        case 21:
            Console.WriteLine();
            Console.WriteLine("         C");
            break;
        case 22:
            Console.WriteLine();
            Console.WriteLine("          C");
            break;
        case 23:
            Console.WriteLine();
            Console.WriteLine("           C");
            break;
        default: break;
    }
    Thread.Sleep(100);
    Console.Clear();
}

Console.WriteLine("Main thread exits.");



