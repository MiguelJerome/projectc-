﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System.Runtime.CompilerServices;
using System.Collections.Specialized;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

using System.Reflection;
using System.IO;
using System.Resources;

using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Media;




using System.Collections.Specialized;
using System.Security.Cryptography.X509Certificates;
using System.Threading;









//GameBreakerPanelMain.showAllGameBreakerPanelLogGameState();
var gameEngine = new GameEngine(); // play engine
