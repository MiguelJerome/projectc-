﻿using System.Runtime.CompilerServices;

class GameEngine
{
    public GameEngine()
    {
        this.StartGameEngine();
        
    }


    public void StartGameEngine()
    {
        this.StartGameMain();
    }

    public void StartGameMain()
    {
        while (this._gameState != _GAME_STOP)
        {
            switch (this._gameState)
            {
                    case _GAME_INITIATE:
                        Console.WriteLine($"Game intitiate log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_TITLE_MENU);
                    break;
                    case _GAME_TITLE_MENU:
                        Console.WriteLine($"Game Title Menu log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_MAIN_MENU);
                    break;
                    case _GAME_MAIN_MENU:
                        Console.WriteLine($"Game Main Menu log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_GAME_LOOP);
                    break;
                    case _GAME_GAME_LOOP:
                        Console.WriteLine($"Game loop log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_INPUT);
                    break;
                    case _GAME_INPUT:
                        Console.WriteLine($"Game Input log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_LOGIC);
                    break;
                    case _GAME_LOGIC:
                        Console.WriteLine($"Game Logic log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_REFRESH);
                    break;
                    case _GAME_REFRESH:
                        Console.WriteLine($"Game Refresh log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_OUTPUT_SCREEN);
                    break;
                    case _GAME_OUTPUT_SCREEN:
                        Console.WriteLine($"Output Screen log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_RESTART);
                    break;
                    case _GAME_RESTART:
                        Console.WriteLine($"Game Restart log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_EXIT);
                    break;
                    case _GAME_EXIT:
                        Console.WriteLine($"Game Exit log");
                        Console.ReadKey();
                        this.SetGameState(_GAME_STOP);
                        this.StopGameEngine();
                    break;
                    default: break;
            }
        }
    }

    public void SetGameState(int gameState)
    {
        this._gameState = gameState;
    }



    public void StopGameEngine()
    {
        Console.WriteLine($"Merci d avoir jouer au jeu de PACMAN");
        Console.WriteLine($"Bye");
    }

    private const int _GAME_INITIATE = 1;
    private const int _GAME_TITLE_MENU = 2;
    private const int _GAME_MAIN_MENU = 3;
    private const int _GAME_GAME_LOOP = 4;
    private const int _GAME_INPUT = 5;
    private const int _GAME_LOGIC = 6;
    private const int _GAME_REFRESH = 7;
    private const int _GAME_OUTPUT_SCREEN = 8;
    private const int _GAME_RESTART = 9;
    private const int _GAME_EXIT = 10;
    private const int _GAME_STOP = 11;
    private int _gameState = 1;
}